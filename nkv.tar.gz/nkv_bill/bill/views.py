# -*- coding: utf-8 -*-
from django.shortcuts import render
from django.http import HttpResponse
import json
#import xdrlib
#import xlrd
import logging
import os
import io
import sys
import time
import datetime
import os.path
import collections

reload(sys)
sys.setdefaultencoding('utf-8')

from enum import Enum

RELATIVE_PATH="/home/hzmaoyingchun/python_tool/python_nkv/nkv_bill/bill/"
BILL_START_TIME="2019-06-06 00:00:00"
FILE_BILL = "nkv_bill.log"
LOG_FILE = "nkv.log"

CLUSTER_DIR_FORMAT = "cluster-"
TENANT_DIR_FORMAT = "tenant-"
CLUSTER_INFO = RELATIVE_PATH+"clusters.info"
TENANT_INFO = RELATIVE_PATH+"tenants.info"
HOST_CONFIG = "hosts.json"
TENANT_CONFIG = "tenant.json"
CLIENT_IP = ""



HOST_ARGS={'ip':'内网ip', 'cluster':'集群', 'memory':'内存', 'status':'状态'}
TENANT_ARGS=["start_time", "end_time", "amount"]

#logging.basicConfig(level=logging.INFO,
#		    filename=LOG_FILE,
#		    filemode='ab+',
#		    format="%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s")

logging.basicConfig()
log_nkv = logging.getLogger("nkv")
handle = logging.handlers.TimedRotatingFileHandler(filename=LOG_FILE,when='W0',interval=1,backupCount=4)

log_nkv.setLevel(logging.INFO)
handle.setFormatter(logging.Formatter("%(asctime)s - %(filename)s[line:%(lineno)d] - %(levelname)s: %(message)s"))

log_nkv.addHandler(handle)

def open_file(file_name, need_exists):

	if os.path.exists(file_name) == False and need_exists == True:
		log_nkv.warning("Open file : %s failed, as it is not exists", file_name)
		return -1
	
	fp = open(file_name, "rb")	
	
	return fp


def time_transfer_str(tmstamp):
	time_local = time.localtime(tmstamp)
	dt_str = time.strftime("%Y-%m-%d %H:%M:%S",time_local)
	return dt

def str_transfer_time(str_time):
	timeArray = time.strptime(str_time, "%Y-%m-%d %H:%M:%S")
	dt_new = time.mktime(timeArray)

	return int(round(dt_new*1000))

def get_timestamp_now():
	return int(round(time.time()*1000))

def get_tenants():
	
	data = open_file(TENANT_INFO, True)
        if data == -1:
		return None 

        dict_js = json.load(data)
	tenant_set = dict_js.keys()
	
	data.close()

	return tenant_set	

# 0 means failed, 1 means success.
def tenant_check(tenant_name):
	tenant_set = get_tenants()
	assert len(tenant_set) >= 0
	name = tenant_name.encode('utf-8')
	
	if name in tenant_set:
		return 1
	else:
		return 0

def get_clusters():
	data = open_file(CLUSTER_INFO, True)
	if data == -1:
		return None

	dict_js = json.load(data)
	cluster_set = dict_js.keys()
	data.close()

	return cluster_set

def cluster_check(cluster_id):
	cluster_set = get_clusters()
	assert len(cluster_set) >= 0
	
	name = cluster_id.encode('utf-8')
	
	if name in cluster_set:
		return 1
	else:
		return 0 	


def get_info(file_name):
	data = open_file(file_name, True)
	if data == -1:
		log_nkv.error("open file %s failed", CLUSTER_INFO)
		return None
	
	dict_js = json.load(data)
	infos = dict_js.items()
	data.close()

	return infos

def find_cluster_name(cluster_id):
	info = get_info(CLUSTER_INFO)
	cluster_name = None
	for cluster in info:
		name = cluster[1][0]['name']
		if cmp(name, cluster_id) == 0:
			return cluster[0].encode('utf-8')			

	return cluster_name

def find_tenant_name(tenant_id):
	info = get_info(TENANT_INFO)
	tenant_name = None
	for key,value in info:
		if cmp(key,tenant_id) == 0:
			tenant_name = value[0]['name']
			break

	return tenant_name

def find_tenant_code(tenant_name):
	info = get_info(TENANT_INFO)
	tenant_code = None
	for key,value in info:
		for t_dict in value:
			if tenant_name in t_dict.values():
				tenant_code = t_dict["code"]
				return tenant_code
	
	return tenant_code

def to_json_Dicts(lists, bill_list):

	for i in lists:
		bill_list.append(i)

	return

def get_hosts_config(fd, start_t, end_t):
	host_json = json.load(fd)
	list_hosts = []
	
	for key, items in host_json.items():
		dict_host = {}
		host_name = key
		pri_ip = ""
		mount = ""
		status = ""
		dict_mem = {}
		for item in items:
			if HOST_ARGS['status'].decode('utf-8') in item.keys():
				status = item[HOST_ARGS['status'].decode('utf-8')]		
			if HOST_ARGS['ip'].decode('utf-8') in item.keys():
				pri_ip = item[HOST_ARGS['ip'].decode('utf-8')]
			if HOST_ARGS['memory'].decode('utf-8') in item.keys():
				mem_list = item[HOST_ARGS['memory'].decode('utf-8')]		
				for mem in mem_list:
					mount = mem["memory"]
					time  = mem["end_time"]		
					if cmp(time, 'none') != 0:
						t = str_transfer_time(time)
						if t > start_t:
							dict_mem[t] = mount
						if t >= end_t:
							break
		 			else:
						dict_mem[time] = mount
						break
					
		assert len(dict_mem) > 0		
#		print "+++++++++++++++++hostName %s" % host_name
#		print "memory ++++ %s" % dict_mem
		dict_host['hostName'] = host_name
		dict_host['hostIp'] = pri_ip
		dict_host['memory'] = dict_mem
				
		list_hosts.append(dict_host)		
	
	return list_hosts

def get_tenant_config(fd, start_t, end_t):
	tenant_json = json.load(fd)
	dict_tenant = {}
	
	
	for key,items in tenant_json.items():
		for item in items:
			start_time = 0
			end_time  = ""
			mount = ""
			#print item
			#print item.values()
			for opt in item.values():
				#print " opt is %s " % opt
				for m in opt:			
					if TENANT_ARGS[0] in m.keys():
						start_time = str_transfer_time(m[TENANT_ARGS[0]])	
					elif TENANT_ARGS[1] in m.keys():
						end_time = m[TENANT_ARGS[1]]
					elif TENANT_ARGS[2] in m.keys():
						mount = m[TENANT_ARGS[2]]	
			
			if cmp(end_time, 'none') != 0:
				end_tm = str_transfer_time(end_time)
				if end_tm > start_t:
					dict_tenant[end_tm] = mount
				if end_t <= end_tm:
					return dict_tenant

			else:
				dict_tenant[end_time] = mount
				#print dict_tenant.items()
				return dict_tenant
	
#	print dict_tenant.items()
	return dict_tenant
							

def get_tenants_config(fd, cluster_name, start_t, end_t):
	tenant_json = json.load(fd)
	list_tenants = []
	
	for key,items in tenant_json.items():
		for item in items:	
			tenant_name = find_tenant_name(item)
			tenant_mount = {}
			tenant_mount_dict = {}
			tenant_pref = TENANT_DIR_FORMAT+tenant_name+"-"
			tenant_dir = RELATIVE_PATH+TENANT_DIR_FORMAT+tenant_name+"/"
			tenant_cluster_file = tenant_pref+cluster_name+".info"
			#print "tenant dir is %s file is %s", tenant_dir, tenant_cluster_file
			for file in os.listdir(tenant_dir):				
				if cmp(file, tenant_cluster_file) == 0:
					t_c_f_t = tenant_dir+file
					data = open_file(t_c_f_t, True)
					tenant_mount_dict = get_tenant_config(data, start_t, end_t)
					data.close()	
					tenant_mount[tenant_name] = tenant_mount_dict	 	
					list_tenants.append(tenant_mount)			

	return list_tenants

def get_period_time(host_list, tenant_list):	
	list_time = []
	
	for host in host_list:
		dict_mem = host['memory']	
		for t in dict_mem.keys():
			if t not in list_time:
				list_time.append(t)

	for tenant in tenant_list:
		for key,value in tenant.items():
			for t in value.keys():
				if t not in list_time:
					list_time.append(t)
	

	list_time.sort()
	#print "get_period time is %s" % list_time
	return list_time	
	
def get_period_host(host_list, time):
	host_info = []
	total_mount = 0
	for host in host_list:
		host_dict = collections.OrderedDict()
		dict_mem = host["memory"]
		#print " ************ %s" % dict_mem
		keys = sorted(dict_mem.keys())
		for i in keys:
			if cmp(i, "none") != 0 and int(i) < time:
				continue
			host_dict["hostName"] = host["hostName"]
			host_dict["hostIp"] = host["hostIp"]
			total_mount += int(dict_mem[i])
		 	host_dict["memory"] = int(dict_mem[i])
			host_info.append(host_dict)
			break		
	
	return total_mount, host_info

def get_period_tenant(tenant_list, time):
	tenant_info = []
	for tenant in tenant_list:
		for key,value in tenant.items():
			tenant_dict = collections.OrderedDict()
			for t in value.keys():
				if cmp(t, "none") != 0 and int(t) < time:
					continue
				tenant_dict["costCenter"] = find_tenant_code(key)
				tenant_dict["useMemory"] = int(value[t])		
				tenant_info.append(tenant_dict)
				break
	
	return tenant_info


def create_cluster_bill_json(cluster, host_list, tenant_list, begin_t, end_t):
	bill_list = []
	cluster_name = find_cluster_name(cluster)
	modify_period_dict = get_period_time(host_list, tenant_list)		
	now_t = get_timestamp_now()	
	#print modify_period_dict

	for time in modify_period_dict:
		total_mem,host_lst = get_period_host(host_list, time)
		tenant_lst = get_period_tenant(tenant_list, time)
		if total_mem == 0 or len(host_lst) == 0 or len(tenant_lst) == 0:
			log_nkv.info("cluster %s has host %d and total memory is %d and tenant is %s between time %d -- %s", cluster_name, len(host_lst), total_mem, len(tenant_lst), begin_t, str(time))
			continue
			
		cluster_dict = collections.OrderedDict()
		cluster_dict["clusterName"] = cluster_name
		cluster_dict["timestmap"] = now_t
		cluster_dict["startTime"] = begin_t
		if cmp(time, "none") == 0:
			cluster_dict["endTime"] = end_t
		elif int(time) < end_t:
			cluster_dict["endTime"] = int(time)
		else:
			cluster_dict["endTime"] = end_t

		#return the host and tenant list
	
		cluster_dict["total_memory"] = total_mem
		cluster_dict["clusterInfo"] = host_lst
		cluster_dict["usageInfo"] = tenant_lst	
		
		bill_list.append(cluster_dict)
		if cluster_dict["endTime"] == end_t:
			break
		begin_t = cluster_dict["endTime"]

	return bill_list		
	
def request_params_check(request):
	args = request.GET.dict()
	len_args = len(args)
	tenant_Name = request.GET.get('tenantId', None)
        begin_Time = request.GET.get('startTime', None)
        end_Time   = request.GET.get('endTime', None)
        cluster_Id =  request.GET.get('clusterName', None)
	log_nkv.info("[REQUEST] tenant name %s, cluster name %s, begin Time %s end Time %s", tenant_Name, cluster_Id, str(begin_Time), str(end_Time))

	if len_args > 4 or len_args < 2:
                log_nkv.error("receive the bad request params: %s ", args.items())
                err_str = "Invalid Method"
                status = 406
                return err_str, status	
	
	for prams in args.keys():
		token = 0
		if cmp(prams, "tenantId") == 0:
			token = 1
		elif cmp(prams, "startTime") == 0:
			token = 1
		elif cmp(prams, "endTime") == 0:
			token = 1
		elif cmp(prams, "clusterName") == 0:
			token = 1

		if token != 1:
			log_nkv.error("receive the bad request params: %s", args.keys())
			err_str = "Invalid Method"
			status = 406
			return err_str, status
	
        if begin_Time == None or end_Time == None:
                log_nkv.error("receive the bad request Time params: lose one")
		err_str = "Invalid Method, Must have begin and end Time Both"
		status = 405
	
		return err_str,status
	
	# this place will know the date time format as string.
	begin_T = int(begin_Time)
	end_T = int(end_Time)
 	tody = datetime.date.today()
	tody_ms = time.mktime(time.strptime(str(tody), '%Y-%m-%d'))
	tody_T = int(round(tody_ms*1000))	
	# bill unit is more than one day.
	if begin_T >= end_T or end_T - begin_T < 86400000:
		log_nkv.error("receive the bad request Time params: endTime %s is smaller than startTime %s", end_Time, begin_Time)
                err_str = "Invalid Method, Must have begin < end Time"
		status = 405
		return err_str, status
		
               
	# this will be make sure when the end time is request.... #	
	if tody_T < end_T :
		log_nkv.error("receive the bad request Time params: endTime %s is big than tody Time %s", end_Time, tody)
                err_str = "Invalid Method, Must have tody > end Time"
		status = 405
		return err_str, status
	
	
	start_arr = time.strptime(BILL_START_TIME, '%Y-%m-%d %H:%M:%S')
	start_tmp = int(round(time.mktime(start_arr) * 1000))
		
	if begin_T < start_tmp:
		log_nkv.error("receive the bad request Time params: startTime %s is smaller than Bill statistic Time %s", begin_Time, BILL_START_TIME)
        	err_str = "Invalid Method, Must have  begin Time >= bill start time(2019-06-06 00:00:00)"
		status = 405
	     	return err_str,status
              
	
	if tenant_Name != None and tenant_check(tenant_Name) == 0:
		log_nkv.error("receive the bad request: %s tenant not exist.", tenant_Name)
                err_str = "Invalid Method, Tenant Name not exist"
		status = 405
		return err_str, status
       
	
	if cluster_Id != None and cluster_check(cluster_Id) == 0:
		log_nkv.error("receive the bad request: %s cluster not exist.", tenant_Name)
                err_str = "Invalid Method, cluster not exist"
		status = 405
	
       		return err_str, status
 
	return "",0


def get_bill_statistics_by_cluster(cluster_id, begin_time, end_time):
	log_nkv.info("[BILL] Client (%s) request the bill statistic by cluster %s from %s to %s", CLIENT_IP, cluster_id, begin_time, end_time)		
	begin_t = int(begin_time)
	end_t   = int(end_time)
	
	cluster_set = get_info(CLUSTER_INFO)
	assert len(cluster_set) > 0
	
	cluster_bill = []
	cluster_bill_json = []
	total_mem = 0
	cluster_name = ""
	for key,values in cluster_set:
		if cmp(cluster_id, key) == 0:
			cluster_name = values[0]['name']
			status = values[1]['stats']
                	off_time = values[2]['offtime']
                	if cmp(status, 'offline') == 0 and cmp(off_time, 'none') != 0:
                        	off_t = str_transfer_time(off_time)
                        	if off_t <= begin_t:
                                	log_nkv.error(" request a offline cluster %s",cluster_id)
					resp = "Cluster : "+cluster_id+" is offline"
					return HttpResponse(resp, status=406,content_type="application/json;charset=UTF-8")

                        	if end_t > off_t:
                                	log_nkv.warning(" request a offline cluster and the end time is bigger than offline time")		
			break
	
	assert cluster_name != ""

	file_dir = RELATIVE_PATH+CLUSTER_DIR_FORMAT + cluster_name+"/"
        
        host_list = []
        tenant_list = []
        cluster_bill_list = []
        files = os.listdir(file_dir)
        for file in files:
        	if not os.path.isdir(file):
                	file_t = file_dir+file	
                	data = open_file(file_t, True)
                	if cmp(file, HOST_CONFIG) == 0:
                        	host_list = get_hosts_config(data, begin_t, end_t)
                        elif cmp(file, TENANT_CONFIG) == 0:
                        	tenant_list = get_tenants_config(data, cluster_name, begin_t, end_t)

                 	data.close()

        if len(host_list) == 0 or len(tenant_list) == 0:
         	log_nkv.warning("Client (%s) requst for the bill statistics but cluster %s has %d host and tenant find", CLIENT_IP, cluster, len(host_list), len(tenant_list))
        	return HttpResponse("request cluster id has no fit bill between the time", status=406, content_type="application/json;charset=UTF-8")

        #return dict list
        cluster_bill_list = create_cluster_bill_json(cluster_name, host_list, tenant_list, begin_t, end_t)
        to_json_Dicts(cluster_bill_list, cluster_bill_json)	
	
	all_bill = json.dumps(cluster_bill_json, ensure_ascii=False)
	log_nkv.info("[BILL] %s", all_bill)
	
	return HttpResponse(all_bill, status=200,content_type="application/json;charset=UTF-8")

	
def get_bill_statistics_by_tenant(begin_time, end_time, tenant_Name):
	log_nkv.info("[BILL] Client (%s) request the Tenant (%s) bill statistics from %s to %s", CLIENT_IP, tenant_Name, begin_time, end_time)
	
	begin_t = int(begin_time)
        end_t   = int(end_time)
	tenans_dict = collections.OrderedDict()

        tenants_set = get_info(TENANT_INFO)
        assert len(tenants_set) > 0
	tenant_name = ""
	for key, value in tenants_set:
		if cmp(key, tenant_Name) == 0:
			tenant_name = value[0]['name']
			break
	
	list_clusters = []
	assert tenant_name != ""
	tenant_dir = RELATIVE_PATH+TENANT_DIR_FORMAT+tenant_name+"/"
        #print "tenant dir is %s " % tenant_dir
        for file in os.listdir(tenant_dir):
        	t_c_f_t = tenant_dir+file	
                data = open_file(t_c_f_t, True)	
                tenant_mount_dict = get_tenant_config(data, begin_t, end_t)
		data.close()
		if len(tenant_mount_dict) == 0:	
			continue
		
		data = open_file(t_c_f_t, True)	
		dict_cluster = json.load(data) #can't repeat load for a open json fd
		cluster_id = dict_cluster.keys()[0] #get the cluster id
                data.close()
		tenant_mount = collections.OrderedDict()
                tenant_mount[cluster_id] = tenant_mount_dict
                list_clusters.append(tenant_mount)		
	
	if len(list_clusters) == 0:
		log_nkv.warning("Client (%s) requst for the bill statistics but tenant %s has no usage in any cluster", CLIENT_IP, tenant_Name)
                return HttpResponse("request tenant has no fit bill between the time", status=406, content_type="application/json;charset=UTF-8")
	       	
	
	tenans_dict["costCenter"] = find_tenant_code(tenant_Name)
	tenans_dict["timestamp"] = get_timestamp_now()
	cluster_usage = []
	for cluster_info in list_clusters:	
		for key,value in cluster_info.items():
			begin_t = begin_time
			# need be sequence
			for time,mount in value.items():
				dict_c = collections.OrderedDict()
				dict_c["clusterName"] = key
				dict_c["startTime"] = begin_t
				if cmp(time, "none") == 0:
					dict_c["endTime"] = end_time
				else:
					dict_c["endTime"] = int(time)
					begin_t = int(time)
		
				dict_c["useMemory"] = int(mount)
				cluster_usage.append(dict_c)		
       	
	tenans_dict["clusterInfo"] = cluster_usage
	
	cluster_bill_json = []
	cluster_bill_json.append(tenans_dict)
        all_bill = json.dumps(cluster_bill_json, ensure_ascii=False)
        log_nkv.info("[BILL] %s", all_bill)

        return HttpResponse(all_bill, status=200, content_type="application/json;charset=UTF-8")

def get_total_bill_statistics(begin_Time, end_Time):
	log_nkv.info("[BILL] Client (%s) request the bill statistics from %s to %s", CLIENT_IP, begin_Time, end_Time)
	
	begin_t = int(begin_Time)
	end_t   = int(end_Time)
	
	cluster_set = get_info(CLUSTER_INFO)
	assert len(cluster_set) > 0
	
	cluster_bill = []
	clusters_bill_json = []
	total_mem = 0

	for cluster in cluster_set:
		name = cluster[1][0]['name']	
		status = cluster[1][1]['stats']	
		off_time = cluster[1][2]['offtime']
		if cmp(status, 'offline') == 0 and cmp(off_time, 'none') != 0:
			off_t = str_transfer_time(off_time)
			if off_t <= begin_t:
				continue
			
			if end_t > off_t:
				log_nkv.warning(" request a offline cluster and the end time is bigger than offline time")
	
		cluster_bill.append(name)

	
	for cluster in cluster_bill:
		file_dir = CLUSTER_DIR_FORMAT + cluster+"/"
		#print("file name is %s" % file_dir)
		host_list = []
		tenant_list = []
		cluster_bill_list = []
		files = os.listdir(RELATIVE_PATH+file_dir)
		for file in files:
			if not os.path.isdir(file):
				file_t = RELATIVE_PATH+file_dir+file
				#print " the file is %s" % file_t
				data = open_file(file_t, True) 
				if cmp(file, HOST_CONFIG) == 0:
					host_list = get_hosts_config(data, begin_t, end_t)			
				elif cmp(file, TENANT_CONFIG) == 0:
					tenant_list = get_tenants_config(data, cluster, begin_t, end_t)
				
				data.close()
		
		if len(host_list) == 0 or len(tenant_list) == 0:
			log_nkv.info("Client (%s) requst for the bill statistics but cluster %s has %d host and %d tenant find",CLIENT_IP, cluster, len(host_list), len(tenant_list))
			continue
		#return dict list
		cluster_bill_list = create_cluster_bill_json(cluster, host_list, tenant_list, begin_t, end_t)
		to_json_Dicts(cluster_bill_list, clusters_bill_json)	
		#print cluster_bill_list	
			
	
	if len(clusters_bill_json) == 0:	
		log_nkv.warning("Client (%s) requst for the bill statistics but has no host and tenant find", CLIENT_IP)
		return HttpResponse('Bill statistic is NULL, as find no host or tenant in cluster.', status=406, content_type="application/json;charset=UTF-8")			
	
	all_bill = json.dumps(clusters_bill_json, ensure_ascii=False)

	log_nkv.info("[BILL] %s",all_bill)
	
	return HttpResponse(all_bill, status=200, content_type="application/json;charset=UTF-8")	
		
def statistic_process(request):
	err_str,stat= request_params_check(request)
	
	tenant_Name = request.GET.get('tenantId', None)
        begin_time = request.GET.get('startTime', None)
        end_time   = request.GET.get('endTime', None)
        cluster_Id =  request.GET.get('clusterName', None)
	
	if err_str != "":
		return HttpResponse(err_str, status=stat, content_type="application/json;charset=UTF-8")
	
	if cluster_Id == None and tenant_Name == None:
		return get_total_bill_statistics(begin_time,end_time)
	
	if tenant_Name != None and cluster_Id == None:
		return get_bill_statistics_by_tenant(begin_time, end_time, tenant_Name)

	if cluster_Id != None and tenant_Name == None:
		return get_bill_statistics_by_cluster(cluster_Id, begin_time, end_time)

	return HttpResponse(u"不支持的请求", status=406, content_type="application/json;charset=UTF-8")	

# Create your views here.
def statistic(request):
	#print "timezone %s" % time.strftime("%Z", time.localtime()) 
	client = request.META.get("HTTP_X_FORWARDED_FOR", "")
	if not client:
		client = request.META.get('REMOTE_ADDR', "")
	
	global CLIENT_IP	
	CLIENT_IP = client.split(",")[-1].strip() if client else ""
 	#print CLIENT_IP
	tt = request.get_full_path().decode('utf-8')
	
	sub="/nkv/statistic"

	list=tt.split("?")
	if  cmp(sub, list[0]) != 0:
		log_nkv.error("[REQUEST] error request %s", tt);
		return HttpResponse(u"错误请求", status=406, content_type="application/json;charset=UTF-8")
	#print request.GET.dict()	
	if  request.method == 'GET':	
		return statistic_process(request)
	elif request.method == 'POST':
		log_nkv.error("[REQUEST] error request for post %s", tt)
		return HttpResponse(u"错误请求", status=406, content_type="application/json;charset=UTF-8")


