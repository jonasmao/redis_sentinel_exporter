#!/bin/bash

if [ $1 == "start" ]
then
	nohup python manage.py runserver 0.0.0.0:10000 > /dev/null & 2>&1
	exit 0
fi

if [ $1 == "stop" ]
then
	pids=`ps -ef|grep runserver|grep 10000|grep -v grep|awk '{print $2}'`
	for i in ${pids[@]}
	do
		kill -9 $i
	done
	exit 0
fi

